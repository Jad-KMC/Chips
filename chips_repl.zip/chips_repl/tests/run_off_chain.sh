#!/bin/bash

pact off_chain.repl |tail -1| jq
